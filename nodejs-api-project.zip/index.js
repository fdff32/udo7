const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to simulate async processing
app.use((req, res, next) => {
    console.log(`Received request: ${req.method} ${req.url}`);
    setTimeout(() => next(), 100);
});

app.get('/', (req, res) => {
    res.send('Welcome to the Node.js API');
});

app.get('/data', async (req, res) => {
    // Simulate a long async task
    await new Promise(resolve => setTimeout(resolve, 500));
    res.json({ message: 'Data fetched successfully' });
});

app.get('/status', (req, res) => {
    res.json({ status: 'API is running', time: new Date().toISOString() });
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
