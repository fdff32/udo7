# Node.js API Project

## Description
This is a simple Node.js API using Express.js that simulates handling concurrent requests using asynchronous operations.

## Features
- Simulates async task delays
- Handles concurrent connections efficiently
- Easy to scale and extend

## Installation & Run
```bash
npm install
npm start
```

## Routes
- `/` - Root welcome message
- `/data` - Simulates data fetching with delay
- `/status` - Returns current API status and time

## Scalability
This project follows a scalable architecture using Express middleware and asynchronous handling. It's designed for real-time and concurrent request environments.
