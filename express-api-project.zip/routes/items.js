const express = require('express');
const router = express.Router();
const { items, getItemIndexById } = require('../data');

router.get('/', (req, res) => {
  res.json(items);
});

router.get('/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const item = items.find(i => i.id === id);
  if (!item) return res.status(404).json({ error: 'Item not found' });
  res.json(item);
});

router.post('/', (req, res) => {
  const { name, description } = req.body;
  if (!name || !description) {
    return res.status(400).json({ error: 'Name and description are required' });
  }
  const newItem = {
    id: items.length + 1,
    name,
    description
  };
  items.push(newItem);
  res.status(201).json(newItem);
});

router.put('/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = getItemIndexById(id);
  if (index === -1) return res.status(404).json({ error: 'Item not found' });

  const { name, description } = req.body;
  if (!name || !description) {
    return res.status(400).json({ error: 'Name and description are required' });
  }

  items[index] = { id, name, description };
  res.json(items[index]);
});

router.delete('/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = getItemIndexById(id);
  if (index === -1) return res.status(404).json({ error: 'Item not found' });

  const deletedItem = items.splice(index, 1);
  res.json(deletedItem[0]);
});

module.exports = router;