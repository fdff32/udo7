# Express.js CRUD API

## Setup Instructions

1. Clone the repository or download the files.
2. Run `npm install` to install dependencies.
3. Start the server using `npm start`.

The server runs on port 3000 by default.

## API Endpoints

### Root

- `GET /` — Returns "Hello, World!"

### Items

- `GET /items` — Retrieve all items.
- `GET /items/:id` — Retrieve an item by ID.
- `POST /items` — Create a new item.
- `PUT /items/:id` — Update an existing item by ID.
- `DELETE /items/:id` — Delete an item by ID.

## Sample Data Format

```json
{
  "id": 1,
  "name": "Sample Item",
  "description": "This is a sample."
}
```

## Testing

Use Postman or a similar tool to test the endpoints.