const items = [
  { id: 1, name: 'Sample Item 1', description: 'This is a sample item.' }
];

const getItemIndexById = (id) => {
  return items.findIndex(item => item.id === id);
};

module.exports = { items, getItemIndexById };